/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Codigos;
import java.util.ArrayList;
/**
 *
 * @author Mauricio Chulau
 */
public class Grafo {
    
    ArrayList<Nodo> Listanodos; //Array de tamaño variable
    int[][] matriz; //Matriz de conexiones, 1 = conectado, 0 = no conectado
    
    Grafo(int size) //Size --> Cantidad de vertices
    {
        Listanodos = new ArrayList<>();
        matriz = new int[size][size];
    }
    
    public void addNodo(Nodo nodo)
    {
        Listanodos.add(nodo);
    }
    
    public void addArista(int origen, int destino)  //origen es fila, destino es columna
    {
        matriz[origen][destino] = 1; //Conecta
    }
    
    public boolean checkArista(int origen, int destino)
    {
        if (matriz[origen][destino] == 1) 
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public void DFS(int origen)  //Se puede implementar con pilas, pero está implementado con recursividad
    {
        boolean[] visitado = new boolean[matriz.length];
        DFShelper(origen, visitado);   
    }
    private void DFShelper(int origen, boolean[] visitado)
    {
        if (visitado[origen]) 
        {
            return;
        }
        else
        {
            visitado[origen] = true;
            System.out.println(Listanodos.get(origen).data + "= visitado");
        }
        
        for (int i = 0; i < matriz[origen].length; i++) 
        {
            if (matriz[origen][i] == 1) 
            {
                DFShelper(i, visitado);
                System.out.print(Listanodos.get(i).data + " "); //Extra, Para mapear su trayecto (Falta comprobar con prueba de escritorio)
            }
        }
        return;
    }
    
    public void print()
    {
        System.out.print("  ");
        for(Nodo nodo : Listanodos)  //Para cada nodo en la lista
        {
            System.out.print(nodo.data + " ");
        }
        System.out.println("");
        for (int i = 0; i < matriz.length; i++) //Filas
        {
            System.out.print(Listanodos.get(i).data + " ");
            for (int j = 0; j < matriz[i].length; j++) //Columnas
            {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println("");
        }
    }
    
    
    
}
