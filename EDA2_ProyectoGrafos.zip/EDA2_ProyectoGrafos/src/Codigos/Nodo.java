/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Codigos;

/**
 *
 * @author Mauricio Chulau
 */
public class Nodo {
    char data;

    public Nodo(char data) {
        this.data = data; //Contiene algo, puede ser nombre
    }
    
    
            
}
