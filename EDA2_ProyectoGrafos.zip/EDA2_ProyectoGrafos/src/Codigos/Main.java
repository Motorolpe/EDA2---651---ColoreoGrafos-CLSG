/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Codigos;

/**
 *
 * @author Mauricio Chulau
 */
public class Main {
    
    public static void main(String[] args) {
       Grafo grafo = new Grafo(5);
       
       //Crea vertices
        grafo.addNodo(new Nodo('A'));   //0
        grafo.addNodo(new Nodo('B'));   //1
        grafo.addNodo(new Nodo('C'));   //2
        grafo.addNodo(new Nodo('D'));   //3
        grafo.addNodo(new Nodo('E'));   //4
        
        //Conecta vertices
        grafo.addArista(0, 1);  //A a B
        grafo.addArista(1, 2);  //B a C
        grafo.addArista(2, 3);  //C a D
        grafo.addArista(2, 4);  //C a E
        grafo.addArista(4, 0);  //E a A
        grafo.addArista(4, 2);  //E a C
        
        grafo.print();
        
        System.out.println("");
        System.out.println(grafo.checkArista(0, 1));
        System.out.println(grafo.checkArista(0, 2));
        
        System.out.println("");
        grafo.DFS(2);
    }
    
}
