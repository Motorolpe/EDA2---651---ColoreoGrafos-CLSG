/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Codigos;

import Ventanas.MostrarGrafo;
import java.awt.Color;
import javax.swing.JFrame;

/**
 *
 * @author pepe
 */
public class Main 
{
    
    public static void mostrarGrafo(Grafo g1, int numV, int[] resultado) {
        JFrame frame = new JFrame("Visualizador de Grafo");            
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        MostrarGrafo graphPanel = new MostrarGrafo(g1, 10, resultado);
        frame.add(graphPanel);
        frame.pack();
        frame.setLocationRelativeTo(null); 
        frame.setVisible(true);        
    }
    
    public static void main(String[] args) {
        //Establece el número de vertices 
        Grafo grafo1 = new Grafo(10);  // n=10
       
        grafo1.addNodo(new NodoGrafo("SIS. ORGA"));      // 0: SIS.ORGANIZACION (560038)
        grafo1.addNodo(new NodoGrafo("I.A. APLICADA"));      // 1: I.A. APLICADA (560040)
        grafo1.addNodo(new NodoGrafo("CALC. II"));      // 2: CÁLCULO II (560042)
        grafo1.addNodo(new NodoGrafo("FISICA. SIS"));      // 3: FÍSICA PARA SIS (650053)
        grafo1.addNodo(new NodoGrafo("INTRO. PROGRA"));   // 4: INTROD. PROGRAM (650054)
        grafo1.addNodo(new NodoGrafo("ESTRUC. DISC"));  // 5: ESTRUC. DISCRET (650055)
        grafo1.addNodo(new NodoGrafo("COSTEO"));        // 6: COSTEO OPERACIO (560043)
        grafo1.addNodo(new NodoGrafo("ESTAD. PROB"));   // 7: ESTADÍS. Y PROB (560046)
        grafo1.addNodo(new NodoGrafo("CALC. III"));     // 8: CÁLCULO III (560047)
        grafo1.addNodo(new NodoGrafo("MOD. SISTEMAS"));     // 9: MODE INTE SIS (650008)
        
        // Aristas (Conflictos de Horario Forzados)
        grafo1.addArista(0, 1);  // SIS. ORG <-> I.A. APP
        grafo1.addArista(1, 2);  // I.A. APP <-> CALC. II
        grafo1.addArista(2, 3);  // CALC. II <-> FIS. SIS
        grafo1.addArista(3, 4);  // FIS. SIS <-> INTRO. PROG
        grafo1.addArista(4, 5);  // INTRO. PROG <-> ESTRUC. DISC
        grafo1.addArista(5, 6);  // ESTRUC. DISC <-> COSTEO
        grafo1.addArista(6, 7);  // COSTEO <-> ESTAD. PROB
        grafo1.addArista(7, 8);  // ESTAD. PROB <-> CALC. III
        grafo1.addArista(8, 9);  // CALC. III <-> MODE. SIS
        grafo1.addArista(9, 0);  // MODE. SIS <-> SIS. ORG
        
        // Aristas Adicionales (Conflictos Centrales para hacer el grafo1 más denso)
        grafo1.addArista(0, 5);  // SIS. ORG <-> ESTRUC. DISC
        grafo1.addArista(2, 7);  // CALC. II <-> ESTAD. PROB
        grafo1.addArista(4, 8);  // INTRO. PROG <-> CALC. III
        grafo1.addArista(1, 9);  // I.A. APP <-> MODE. SIS
        
        //TEST GREEDY
        System.out.println("");
        System.out.println("TESTING GREEDY");
        Grafo grafo2 = new Grafo(5);
        
        grafo2.addNodo(new NodoGrafo("A"));      
        grafo2.addNodo(new NodoGrafo("B"));      
        grafo2.addNodo(new NodoGrafo("C"));      
        grafo2.addNodo(new NodoGrafo("D"));      
        grafo2.addNodo(new NodoGrafo("E")); 
        
        grafo2.addArista(0, 1, false);
        grafo2.addArista(0, 2, false);
        grafo2.addArista(1, 2, false);
        grafo2.addArista(1, 3, false);
        grafo2.addArista(2, 3, false);
        grafo2.addArista(3, 4, false);
        System.out.println("Matriz de grafo2");
        grafo2.print();
        
        System.out.println("");
        // System.out.println("Coloreo de grafo2 LISTA");
        //grafo2.printColores(grafo2.greedyColoringLista());
        
        System.out.println("");
        // System.out.println("Coloreo de grafo2 MATRIZ");
        // grafo2.printColores(grafo2.greedyColoringMatriz());
        
        //int[] resultado = grafo2.greedyColoringMatriz();
        //mostrarGrafo(grafo2, 5, resultado);
        //System.out.println("");
        
        
        System.out.println("-------TEST WELSH-POWELL-------");
        Grafo grafo3 = new Grafo(5);
        /*
        grafo3.addNodo(new NodoGrafo("A"));      
        grafo3.addNodo(new NodoGrafo("B"));      
        grafo3.addNodo(new NodoGrafo("C"));      
        grafo3.addNodo(new NodoGrafo("D"));      
        grafo3.addNodo(new NodoGrafo("E"));  
        
        grafo3.addArista(0, 1, false);
        grafo3.addArista(0, 2, false);
        grafo3.addArista(1, 2, false);
        grafo3.addArista(1, 4, false);
        grafo3.addArista(2, 4, false);
        grafo3.addArista(4, 3, false);
        System.out.println("Matriz de grafo3");
        grafo3.print();
        
        System.out.println("");
        System.out.println("Coloreo de grafo3 Welsh-Powell");
        int[] resultados3 = grafo3.welshPowellColoring();
        mostrarGrafo(grafo3, 5, resultados3);
        System.out.println("");
        */
        
        //TEST BACKTRACKING
        System.out.println("-------TEST BACKTRACKING-------");
        Grafo grafo4 = new Grafo(5);
        grafo4.addNodo(new NodoGrafo("A"));      
        grafo4.addNodo(new NodoGrafo("B"));      
        grafo4.addNodo(new NodoGrafo("C"));      
        grafo4.addNodo(new NodoGrafo("D"));      
        grafo4.addNodo(new NodoGrafo("E")); 
        
        grafo4.addArista(0, 1, false);
        grafo4.addArista(0, 2, false);
        grafo4.addArista(1, 2, false);
        grafo4.addArista(1, 4, false);
        grafo4.addArista(2, 4, false);
        grafo4.addArista(4, 3, false);
        System.out.println("Matriz de grafo4");
        grafo4.print();
        
        System.out.println("Coloreo de grafo4 con Backtracking");
        int[] resultados4 = grafo4.MegaBTC();
        mostrarGrafo(grafo4, 5, resultados4);
        for (int i=0; i<resultados4.length; i++){
            System.out.print(resultados4[i]+" ");
        }
        System.out.println("");
        
//        
//        System.out.println("");
//        System.out.println("Coloreo de grafo3 MATRIZ");
//        grafo3.printColores(grafo3.greedyColoringMatriz());
//        System.out.println("FIN TESTING GREEDY");
    }

}
