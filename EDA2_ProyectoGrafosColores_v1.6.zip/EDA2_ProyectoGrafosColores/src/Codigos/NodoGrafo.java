/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Codigos;

/**
 *
 * @author Mauricio Chulau
 */
public class NodoGrafo {
    String data;

    public NodoGrafo(String data) {
        this.data = data; //Contiene algo, puede ser nombre
    }
    
    public String getData() {
        return data;
    }

}
