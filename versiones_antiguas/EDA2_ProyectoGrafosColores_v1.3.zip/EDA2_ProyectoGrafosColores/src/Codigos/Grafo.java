/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Codigos;
import java.util.ArrayList;
import java.util.*;
import java.util.LinkedList;
/**
 *
 * @author Mauricio Chulau
 */
public class Grafo {
    
    ArrayList<NodoGrafo> ListaNodos; //Array de tamaño variable
    int[][] matriz; //Matriz de Conexiones, 1 = conectado, 0 = no conectado
    LinkedList<Integer> adj[]; //Lista de adyacencia, en cada nodo almacena un integer (que indica el vertice) 
    int size;
    
    public Grafo(int size) //Size --> Cantidad de vertices
    {
        ListaNodos = new ArrayList<>();
        matriz = new int[size][size];
        this.size = size;
        
        adj = new LinkedList[size];  //Arreglo de Listas enlazadas
        for (int i=0; i<size; ++i)
            adj[i] = new LinkedList();
    }
    
    //Creación de vertices
    public void addNodo(NodoGrafo nodo)
    {
        ListaNodos.add(nodo);
    }
    
    //Conexión de vertices
    public void addArista(int origen, int destino)  //origen es fila, destino es columna
    {
        matriz[origen][destino] = 1; //Conecta en matriz
        adj[origen].add(destino);  //Conecta en lista
    }
    public void addArista(int origen, int destino, boolean esDirigido)  
    {
       //Conecta primer sentido
        matriz[origen][destino] = 1; 
        adj[origen].add(destino);
        if (esDirigido==false) //Si es un grafo NO dirigido
        {
            //establece conexión en el otro sentido
            matriz[destino][origen] = 1; 
            adj[destino].add(origen);
        }
    }
    
    //Revisa si dos vertices están conectados 
    public boolean checkArista(int origen, int destino) //DIRIGIDO, un solo sentido
    {
        if (matriz[origen][destino] == 1) 
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    public boolean checkArista(int origen, int destino, boolean esDirigido) //DIRIGIDO o NO DIRIGIDO
    {
        if(esDirigido == true) //Si es dirigido
        {
            if (matriz[origen][destino] == 1) 
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else  //Si es no dirigido
        {
            if (matriz[origen][destino] == 1 && matriz[destino][origen] == 1) 
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
    
   

    //Print de la Matriz de Conexiones
    public void print()
    {
        System.out.print("  ");
        for(NodoGrafo nodo : ListaNodos)  //Para cada nodo en la lista
        {
            System.out.print(nodo.data + " ");
        }
        System.out.println("");
        for (int i = 0; i < matriz.length; i++) //Filas
        {
            System.out.print(ListaNodos.get(i).data + " ");
            for (int j = 0; j < matriz[i].length; j++) //Columnas
            {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println("");
        }
    }

    public ArrayList<NodoGrafo> getListaNodos() {
        return ListaNodos;
    }

    public int[][] getMatrizAdyacencia() {
        return matriz;
    }

    public int getSize() {
        return size;
    }
    
    //MAURICIO
    public int[] greedyColoringLista()
    {
        //Arreglo donde cada indice (vertice) tendrá un color
        int resultado[] = new int[size];
        //Al principio, TODOS los vertices no tienen un color asignado
        Arrays.fill(resultado, -1);

        //Se le asigna el primero color al primer vertice
        resultado[0] = 0;

        //Arreglo que almacena la disponibilidad de los colores (se irá renovando en cada iteracion)
        //Si disponible[color] es FALSE, entonces ese color ha sido asignado a uno de sus vecinos
        boolean disponible[] = new boolean[size];       
        //Todos los colores estan disponibles al principio
        Arrays.fill(disponible, true);

        //Bucle para Asignacion de color a los vertices que quedan
        for (int j = 1; j<size; j++)
        {
            Iterator<Integer> iter = adj[j].iterator(); //Funcionalmente, Iterator empieza en una posición PREVIA al primer elemento de la lista enlazada
            while (iter.hasNext()) //Itera por CADA vecino que tenga el vertice
            {
                int vert = iter.next(); //Itera (Avanza al siguiente nodo de la lista), vert se vuelve el indice (vertice) que este nodo representa.
                if (resultado[vert] != -1)  //Si su vecino TIENE color[i] asignado
                    disponible[resultado[vert]] = false;  //Marca color[i] como NO Disponible
            }

            //Busca el primer color disponible
            int color;
            for (color = 0; color<size; color++){
                if (disponible[color])
                {
                    break;
                }
            }
            resultado[j] = color; //Le asigna el color encontrado

            //Renueva los valores del arreglo de disponibilidad a TRUE para la siguiente iteracion
            Arrays.fill(disponible, true);
        }

        return resultado;
    }
    
    //MAURICIO
    public int[] greedyColoringMatriz()
    {
        //Arreglo donde cada indice (vertice) tendrá un color
        int resultado[] = new int[size];
        //Al principio, TODOS los vertices no tienen un color asignado
        Arrays.fill(resultado, -1);

        //Se le asigna el primero color al primer vertice
        resultado[0] = 0;

        //Arreglo que almacena la disponibilidad de los colores (se irá renovando en cada iteracion)
        //Si disponible[color] es FALSE, entonces ese color ha sido asignado a uno de sus vecinos
        boolean disponible[] = new boolean[size];       
        //Todos los colores estan disponibles al principio
        Arrays.fill(disponible, true);

        //Bucle para Asignacion de color a los vertices que quedan
        for (int j = 1; j<size; j++)
        {
            
            for (int i = 0; i < size; i++) //Recorre la matriz de adyacencia
            {
                if (matriz[j][i] == 1) //Si es vecino
                {
                    if (resultado[i] != -1)  //Si su vecino TIENE color[i] asignado
                        disponible[resultado[i]] = false;  //Marca color[i] como NO Disponible
                }
            }
            
            //Busca el primer color disponible
            int color;
            for (color = 0; color<size; color++){
                if (disponible[color])
                {
                    break;
                }
            }
            resultado[j] = color; //Le asigna el color encontrado

            //Renueva los valores del arreglo de disponibilidad a TRUE para la siguiente iteracion
            Arrays.fill(disponible, true);
        }

        return resultado;
    }
    
    public void printColores(int[] resultado)
    {
        for(int u = 0; u < size; u++)
        {
            System.out.println("Vertice " + u + " --> Color " + resultado[u]);
        }
    }
    
}
