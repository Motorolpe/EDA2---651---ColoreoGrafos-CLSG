/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Codigos;

import java.awt.Color;
import static java.awt.Color.WHITE;

/**
 *
 * @author Mauricio Chulau
 */
public class NodoGrafo {
    String data;
    Color color = WHITE;

    public NodoGrafo(String data) {
        this.data = data; //Contiene algo, puede ser nombre
    }

    public Color getColor() {
        return color;
    }    

    public String getData() {
        return data;
    }

}
