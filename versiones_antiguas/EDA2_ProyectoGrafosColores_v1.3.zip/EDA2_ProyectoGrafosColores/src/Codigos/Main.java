/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Codigos;

import Ventanas.MostrarGrafo;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

/**
 *
 * @author pepe
 */
public class Main 
{
    
    public static void main(String[] args) {
        //Establece el número de vertices 
        Grafo grafo = new Grafo(10);  // n=10
       
        grafo.addNodo(new NodoGrafo("SIS. ORGA"));      // 0: SIS.ORGANIZACION (560038)
        grafo.addNodo(new NodoGrafo("I.A. APLICADA"));      // 1: I.A. APLICADA (560040)
        grafo.addNodo(new NodoGrafo("CALC. II"));      // 2: CÁLCULO II (560042)
        grafo.addNodo(new NodoGrafo("FISICA. SIS"));      // 3: FÍSICA PARA SIS (650053)
        grafo.addNodo(new NodoGrafo("INTRO. PROGRA"));   // 4: INTROD. PROGRAM (650054)
        grafo.addNodo(new NodoGrafo("ESTRUC. DISC"));  // 5: ESTRUC. DISCRET (650055)
        grafo.addNodo(new NodoGrafo("COSTEO"));        // 6: COSTEO OPERACIO (560043)
        grafo.addNodo(new NodoGrafo("ESTAD. PROB"));   // 7: ESTADÍS. Y PROB (560046)
        grafo.addNodo(new NodoGrafo("CALC. III"));     // 8: CÁLCULO III (560047)
        grafo.addNodo(new NodoGrafo("MOD. SISTEMAS"));     // 9: MODE INTE SIS (650008)
        
        // Aristas (Conflictos de Horario Forzados)
        // Estructura de anillo (Anillo Exterior) para asegurar que NINGÚN nodo quede solo
        grafo.addArista(0, 1);  // SIS. ORG <-> I.A. APP
        grafo.addArista(1, 2);  // I.A. APP <-> CALC. II
        grafo.addArista(2, 3);  // CALC. II <-> FIS. SIS
        grafo.addArista(3, 4);  // FIS. SIS <-> INTRO. PROG
        grafo.addArista(4, 5);  // INTRO. PROG <-> ESTRUC. DISC
        grafo.addArista(5, 6);  // ESTRUC. DISC <-> COSTEO
        grafo.addArista(6, 7);  // COSTEO <-> ESTAD. PROB
        grafo.addArista(7, 8);  // ESTAD. PROB <-> CALC. III
        grafo.addArista(8, 9);  // CALC. III <-> MODE. SIS
        grafo.addArista(9, 0);  // MODE. SIS <-> SIS. ORG (Cierra el anillo)
        
        // Aristas Adicionales (Conflictos Centrales para hacer el grafo más denso)
        grafo.addArista(0, 5);  // SIS. ORG <-> ESTRUC. DISC
        grafo.addArista(2, 7);  // CALC. II <-> ESTAD. PROB
        grafo.addArista(4, 8);  // INTRO. PROG <-> CALC. III
        grafo.addArista(1, 9);  // I.A. APP <-> MODE. SIS
        
        SwingUtilities.invokeLater(() -> {
        JFrame frame = new JFrame("Visualizador de Grafo");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            
            MostrarGrafo graphPanel = new MostrarGrafo();
            frame.add(graphPanel);

            frame.pack(); // Ajusta el marco al tamaño preferido del panel
            frame.setLocationRelativeTo(null); 
            frame.setVisible(true);
        });
        
        
        //TEST GREEDY
        System.out.println("");
        System.out.println("TESTING GREEDY");
        Grafo grafo2 = new Grafo(5);
        
        grafo2.addNodo(new NodoGrafo("A"));      
        grafo2.addNodo(new NodoGrafo("B"));      
        grafo2.addNodo(new NodoGrafo("C"));      
        grafo2.addNodo(new NodoGrafo("D"));      
        grafo2.addNodo(new NodoGrafo("E")); 
        
        grafo2.addArista(0, 1, false);
        grafo2.addArista(0, 2, false);
        grafo2.addArista(1, 2, false);
        grafo2.addArista(1, 3, false);
        grafo2.addArista(2, 3, false);
        grafo2.addArista(3, 4, false);
        System.out.println("Matriz de grafo2");
        grafo2.print();
        
        System.out.println("");
        System.out.println("Coloreo de grafo2 LISTA");
        grafo2.printColores(grafo2.greedyColoringLista());
        
        System.out.println("");
        System.out.println("Coloreo de grafo2 MATRIZ");
        grafo2.printColores(grafo2.greedyColoringMatriz());
        
        System.out.println("");
        Grafo grafo3 = new Grafo(5);
        
        grafo3.addNodo(new NodoGrafo("A"));      
        grafo3.addNodo(new NodoGrafo("B"));      
        grafo3.addNodo(new NodoGrafo("C"));      
        grafo3.addNodo(new NodoGrafo("D"));      
        grafo3.addNodo(new NodoGrafo("E"));  
        
        grafo3.addArista(0, 1, false);
        grafo3.addArista(0, 2, false);
        grafo3.addArista(1, 2, false);
        grafo3.addArista(1, 4, false);
        grafo3.addArista(2, 4, false);
        grafo3.addArista(4, 3, false);
        System.out.println("Matriz de grafo3");
        grafo3.print();
        
        System.out.println("");
        System.out.println("Coloreo de grafo3 LISTA");
        grafo3.printColores(grafo3.greedyColoringLista());
        
        System.out.println("");
        System.out.println("Coloreo de grafo3 MATRIZ");
        grafo3.printColores(grafo3.greedyColoringMatriz());
        System.out.println("FIN TESTING GREEDY");
    }
        
}
