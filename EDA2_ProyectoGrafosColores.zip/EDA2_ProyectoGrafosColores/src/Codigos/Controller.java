package Codigos;

import TDALista.Nodo;
import TDALista.TDALista;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author rafae
 */
public class Controller {
    
    static TDALista buscarEnLista(TDALista lista, int indice) 
    {
        if (indice > lista.longitud() || indice < 1) {
            throw new RuntimeException("Indice no valido.");
        }
        
        Nodo<TDALista> aux = lista.getCabeza();
        for (int i = 0; i < indice-1; i++) {
            aux = aux.getSgteNodo();
        }

        return aux.getItem();
     }
    
}
