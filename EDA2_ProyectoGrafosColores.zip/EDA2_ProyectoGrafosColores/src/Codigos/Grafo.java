/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Codigos;
import java.util.ArrayList;
/**
 *
 * @author Mauricio Chulau
 */
public class Grafo {
    
    ArrayList<NodoGrafo> Listanodos; //Array de tamaño variable
    int[][] matriz; //Matriz de Conexiones, 1 = conectado, 0 = no conectado
    
    Grafo(int size) //Size --> Cantidad de vertices
    {
        Listanodos = new ArrayList<>();
        matriz = new int[size][size];
    }
    
    //Creación de vertices
    public void addNodo(NodoGrafo nodo)
    {
        Listanodos.add(nodo);
    }
    
    //Conexión de vertices
    public void addArista(int origen, int destino)  //origen es fila, destino es columna
    {
        matriz[origen][destino] = 1; //Conecta
    }
    public void addArista(int origen, int destino, boolean dirigido)  
    {
        matriz[origen][destino] = 1; //Conecta primer sentido
        if (dirigido==false) //Si es un grafo no dirigido
        {
            matriz[destino][origen] = 1; //establece conexión en el otro sentido
        }
    }
    
    //Revisa si dos vertices están conectados 
    public boolean checkArista(int origen, int destino) //DIRIGIDO, un solo sentido
    {
        if (matriz[origen][destino] == 1) 
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    public boolean checkArista(int origen, int destino, boolean dirigido) //DIRIGIDO o NO DIRIGIDO
    {
        if(dirigido == true) //Si es dirigido
        {
            if (matriz[origen][destino] == 1) 
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else  //Si es no dirigido
        {
            if (matriz[origen][destino] == 1 || matriz[destino][origen] == 1) 
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
    
    /*
    public void DFS(int origen)  //Se puede implementar con pilas, pero está implementado con recursividad
    {
        boolean[] visitado = new boolean[matriz.length];
        DFShelper(origen, visitado);   
    }
    private void DFShelper(int origen, boolean[] visitado)
    {
        if (visitado[origen]) 
        {
            return;
        }
        else
        {
            visitado[origen] = true;
            System.out.println(Listanodos.get(origen).data + "= visitado");
        }
        
        for (int i = 0; i < matriz[origen].length; i++) 
        {
            if (matriz[origen][i] == 1) 
            {
                DFShelper(i, visitado);
                System.out.print(Listanodos.get(i).data + " "); //Extra, Para mapear su trayecto (Falta comprobar con prueba de escritorio)
            }
        }
        return;
    }
    */

    //Print de la Matriz de Conexiones
    public void print()
    {
        System.out.print("  ");
        for(NodoGrafo nodo : Listanodos)  //Para cada nodo en la lista
        {
            System.out.print(nodo.data + " ");
        }
        System.out.println("");
        for (int i = 0; i < matriz.length; i++) //Filas
        {
            System.out.print(Listanodos.get(i).data + " ");
            for (int j = 0; j < matriz[i].length; j++) //Columnas
            {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println("");
        }
    }
    
    
    
}
