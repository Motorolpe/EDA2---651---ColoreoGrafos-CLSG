/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Codigos;

import static Codigos.Controller.buscarEnLista;
import TDALista.*;

/**
 *
 * @author pepe
 */
public class Main {
    
    public static void main(String[] args) {
        //Establece el número máximo de vertices 
        Grafo grafo = new Grafo(5);  // n=5
       
        //Crea vertices
        grafo.addNodo(new NodoGrafo('A'));   //0
        grafo.addNodo(new NodoGrafo('B'));   //1
        grafo.addNodo(new NodoGrafo('C'));   //2
        grafo.addNodo(new NodoGrafo('D'));   //3
        grafo.addNodo(new NodoGrafo('E'));   //4
        
        //Conecta vertices
        grafo.addArista(0, 1);  //A a B
        grafo.addArista(1, 2);  //B a C
        grafo.addArista(2, 3);  //C a D
        grafo.addArista(2, 4);  //C a E
        grafo.addArista(4, 0);  //E a A
        grafo.addArista(4, 2);  //E a C
        
        grafo.print();
        System.out.println("");
        
        //Lista de adyacencia
        TDALista listaPrincipal = new TDALista(); //Lista de Listas enlazadas
        TDALista lista2 = new TDALista();
        lista2.agregar("indice 1");
        TDALista lista3 = new TDALista();
        lista3.agregar("indice 2");
        TDALista lista4 = new TDALista();
        lista4.agregar("indice 3");
        listaPrincipal.agregar(lista2);
        listaPrincipal.agregar(lista3);
        listaPrincipal.agregar(lista4);
        TDALista buscado = buscarEnLista(listaPrincipal, 1);
        System.out.println(buscado.getCabeza());
        buscado = buscarEnLista(listaPrincipal, 2);
        System.out.println(buscado.getCabeza());
        buscado = buscarEnLista(listaPrincipal, 3);
        System.out.println(buscado.getCabeza());
        buscado = buscarEnLista(listaPrincipal, 1);
        System.out.println(buscado.getCabeza());
        
        System.out.println("");
        //Test borrado
        listaPrincipal.eliminar(1);
        buscado = buscarEnLista(listaPrincipal, 1);
        System.out.println(buscado.getCabeza());
        buscado = buscarEnLista(listaPrincipal, 2);
        System.out.println(buscado.getCabeza());
        
        
    }
}
