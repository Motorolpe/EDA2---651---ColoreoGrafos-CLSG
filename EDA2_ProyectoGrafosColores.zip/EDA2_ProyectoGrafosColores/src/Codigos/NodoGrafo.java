/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Codigos;

/**
 *
 * @author Mauricio Chulau
 */
public class NodoGrafo {
    char data;
    int color;

    public NodoGrafo(char data) {
        this.data = data; //Contiene algo, puede ser nombre
    }
    
    
            
}
