/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TDALista;

public class Nodo<T> {
    //atributos
    private T item;
    private Nodo<T> sgteNodo; 
    
    //metodos
    //creacion de un nodo
    //constructores sin/con parametros
    public Nodo(){
        item = null;
        sgteNodo = null;
    }
    
    public Nodo(T item){
        this.item = item;
        sgteNodo = null;
    }
    
    public Nodo(T item, Nodo<T> sgteNodo){
        this.item = item;
        this.sgteNodo = sgteNodo;
    }

    public T getItem() {
        return item;
    }

    public void setItem(T item) {
        this.item = item;
    }

    public Nodo<T> getSgteNodo() {
        return sgteNodo;
    }

    public void setSgteNodo(Nodo sgteNodo) {
        this.sgteNodo = sgteNodo;
    }

    @Override
    public String toString() {
        return "Item: " + item;
    }
    
    
    
}
