/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TDALista;

public class TDALista<T> {
    //atributos
    //en todo lugar donde se declara Nodo se pone T
    private Nodo<T> cabeza;
    private Nodo<T> ultimo;
    
    //metodos
    public TDALista(){
        cabeza = null;
        ultimo = null;
    }

    public Nodo <T> getCabeza() {
        return cabeza;
    }

    public void setCabeza(Nodo cabeza) {
        this.cabeza = cabeza;
    }

    public Nodo <T> getUltimo() {
        return ultimo;
    }

    public void setUltimo(Nodo ultimo) {
        this.ultimo = ultimo;
    }
    
    /*
    metodo: es vacio.
    verifica si la lista esta vacia
    */
    public boolean esVacia(){
        return cabeza == null;
    }
    
    /*
    agregar: añade al final de la lista un nuevo nodo
    */
    public void agregar(T item){
        //crear un nuevo nodo
        Nodo<T> nuevo = new Nodo(item, null);
        
        if (esVacia()) {
            //lista esta vacia
            cabeza=nuevo;
            ultimo = nuevo;
        }
        else{
            //lista tiene elementos
            ultimo.setSgteNodo(nuevo);
            ultimo = nuevo;
            
        }
    }
    
    public void mostrar(){
        Nodo<T> aux = cabeza;
        while(aux!=null){ //cuando la lista esta vacia, la cabeza 
            System.out.print(aux.getItem()+"\t");
            aux = aux.getSgteNodo();
        }
        System.out.println();
    }
    
    public int longitud(){ //longitud siempre devuelve cantidad entera
        int n=0;
        if (esVacia()){
            return 0;
        }
        else{
            Nodo<T> aux = cabeza;
            while(aux!=null){ 
                n++;
                aux = aux.getSgteNodo();
            }
            return n;
            }
    }
    
    //devuelve el valor de un item de una posicion dada
    public T iesimo(int pos){
        if (pos>=1 && pos<=longitud()) {
            int i = 1;
            Nodo<T> aux = cabeza;
            while(i<pos){
                aux = aux.getSgteNodo();
                i++;
            }
            return aux.getItem();
        }
        else{
            return null;
        }
    }
    
    //Buscar, ubicacion:devuelve la posicion de un item en la lista
    public int ubicacion(T item){
        if (esVacia()) {
            return -1;
        }
        else{
            int i = 1;
            Nodo<T> aux = cabeza;
            while(aux!=null){
                if (aux.getItem().equals(item)) { //como ahora son genericas, ponerlo con la funcion equals
                    return i;
                }
                    i++;
                    aux = aux.getSgteNodo();
                
                
            }
            return -1;
        }
    }
    
    //insertar: agregar un elemento en una posicion determinada
    public void insertar(T item, int pos){
        if (pos>=1 && pos<=longitud()) {
            Nodo<T> nuevo = new Nodo(item,null);
            //caso 1: insertar en pos 1
            if (pos==1) {
                /*
                Nodo aux = cabeza;
                cabeza = nuevo;
                nuevo.setSgteNodo(aux);
                */
                nuevo.setSgteNodo(cabeza);
                cabeza = nuevo;
            }
            else if(pos>1){
                int i = 1;
                Nodo<T> aux = cabeza.getSgteNodo(); //elemento 2
                while(i<pos-1){
                    aux = aux.getSgteNodo();
                    i++;
                }                
                nuevo.setSgteNodo(aux.getSgteNodo());
                aux.setSgteNodo(nuevo);
            }
        }
        else{
            System.out.println("Posicion no valida");
        }
    }
    
    //eliminar: remueve un item de la lista indicando su posicion
    public void eliminar(int pos){
        if (pos>=1 && pos<=longitud()) {
            if (pos==1) {
                cabeza = cabeza.getSgteNodo();
            }
            else {
                Nodo<T> aux = cabeza;
                int i = 1;
                while(i<pos-1){
                    aux = aux.getSgteNodo();
                    i++;
                }
                if (pos==longitud()) {
                    aux.setSgteNodo(null);
                    ultimo = aux;                    
                }
                else{
                    //borrar en medio
                    Nodo<T> aux2 = aux.getSgteNodo(); //setear uno nuevo al q vamos a borrar
                    aux.setSgteNodo(aux2.getSgteNodo()); //setear el anterior del q vamos a borrar y q apunte a --> el sig del q vamos a borrar (aux2)                    
                }
            }
        }
        else{
            System.out.println("Posicion no valida o lista vacia");
        }
    }

    
}

